package com.example.specsshopify;

import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    List<Order> orders = new ArrayList<Order>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        DownloadTask task = new DownloadTask();
        task.execute("https://specs-shop.myshopify.com/admin/api/2020-10/orders.json?status=any");
    }

    public class DownloadTask extends AsyncTask<String, Void, String> {

        final String basicAuth = "Basic " + Base64.encodeToString("411a5dbf05e33a301fe73e4fc825d0ff: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".getBytes(), Base64.NO_WRAP);

        @Override
        protected String doInBackground(String... urls) {
            String result = "";
            URL url;
            HttpURLConnection urlConnection = null;

            try {
                url = new URL(urls[0]);
                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestProperty ("Authorization", basicAuth);
                InputStream in = urlConnection.getInputStream();
                InputStreamReader reader = new InputStreamReader(in);
                int data = reader.read();
                while(data != -1){
                    char current = (char)data;
                    result += current;
                    data = reader.read();
                }
                return  result;
            } catch (Exception e) {
                e.printStackTrace();
                return "Failed";
            }
        }
        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            //Log.i("JSON", s);
            try {
                JSONObject jsonObject = new JSONObject(s);
                String orderInfo = jsonObject.getString("orders");
                //Log.i("JSON", orderInfo);
                JSONArray arr = new JSONArray(orderInfo);
                for(int i = 0; i < arr.length(); i++){
                    Order order = new Order();
                    JSONObject jsonPart = arr.getJSONObject(i);
                    order.setOrderId(jsonPart.getString("id"));
                    order.setOrderNo(jsonPart.getString("order_number"));
                    order.setCustomerId(jsonPart.getString("user_id"));
                    order.setPaymentStatus(jsonPart.getString("financial_status"));
                    order.setFulfillmentStatus(jsonPart.getString("fulfillment_status"));
                    order.setOrderPrice(jsonPart.getString("total_line_items_price"));
                    orders.add(order);
//                    Log.i("Order ID", jsonPart.getString("id"));
//                    Log.i("Order Number", jsonPart.getString("order_number"));
//                    Log.i("Customer ID", jsonPart.getString("user_id"));
//                    Log.i("payment_status", jsonPart.getString("financial_status"));
//                    Log.i("fulfillment_status", jsonPart.getString("fulfillment_status"));
//                    Log.i("Order Price", jsonPart.getString("total_line_items_price"));

                }
            } catch (Exception e) {
                e.printStackTrace();
            }

            if(orders.size() > 0){
                for(int i = 0; i < orders.size(); i++){
                    Log.i("Order", Integer.toString(i + 1));
                    Log.i("Order ID", orders.get(i).getOrderId());
                    Log.i("Order Number", orders.get(i).getOrderNo());
                    Log.i("Customer ID", orders.get(i).getCustomerId());
                    Log.i("payment_status", orders.get(i).getPaymentStatus());
                    Log.i("fulfillment_status", orders.get(i).getFulfillmentStatus());
                    Log.i("Order Price", orders.get(i).getOrderPrice());
                }
            }

        }
    }

}